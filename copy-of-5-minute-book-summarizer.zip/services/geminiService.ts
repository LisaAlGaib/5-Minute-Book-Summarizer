
import { GoogleGenAI } from "@google/genai";

// Ensure the API key is available as an environment variable
if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function summarizeBook(bookTitle: string): Promise<string> {
  const prompt = `
    Please provide a detailed summary of the book titled "${bookTitle}".
    The summary should cover the main plot, key characters, significant themes, and the overall narrative arc.
    Structure the summary to be easily digestible and readable in approximately 5 minutes.
    Do not include any introductory phrases like 'Here is a summary of...' or 'This is a summary of the book...'.
    Just start directly with the summary content. Format the output with clear paragraphs.
  `;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    
    if (!response.text) {
        throw new Error("The API returned an empty response.");
    }

    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error) {
        // Re-throw a more specific error to be caught by the UI
        throw new Error(error.message || "Failed to communicate with the Gemini API.");
    }
    throw new Error("An unknown error occurred while fetching the summary.");
  }
}
