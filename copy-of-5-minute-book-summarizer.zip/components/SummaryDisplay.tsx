
import React from 'react';

interface SummaryDisplayProps {
  summary: string;
  isLoading: boolean;
  error: string | null;
}

const SummaryDisplay: React.FC<SummaryDisplayProps> = ({ summary, isLoading, error }) => {
  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center text-center p-8">
          <div className="w-16 h-16 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-4 text-lg font-semibold text-gray-700 dark:text-gray-300">Generating your summary...</p>
          <p className="text-gray-500 dark:text-gray-400">This might take a moment.</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="bg-red-100 dark:bg-red-900/30 border-l-4 border-red-500 text-red-700 dark:text-red-300 p-4 rounded-md" role="alert">
          <p className="font-bold">Error</p>
          <p>{error}</p>
        </div>
      );
    }

    if (summary) {
      return (
        <div>
          <h2 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">Summary</h2>
          <div className="prose prose-lg dark:prose-invert max-w-none text-gray-700 dark:text-gray-300 leading-relaxed" style={{ whiteSpace: 'pre-wrap' }}>
            {summary}
          </div>
        </div>
      );
    }

    return (
      <div className="text-center p-8 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg">
        <h3 className="text-xl font-medium text-gray-700 dark:text-gray-300">Your summary will appear here</h3>
        <p className="mt-2 text-gray-500 dark:text-gray-400">Enter a book title above and click "Summarize" to begin.</p>
      </div>
    );
  };

  return <div className="mt-6 min-h-[200px]">{renderContent()}</div>;
};

export default SummaryDisplay;
